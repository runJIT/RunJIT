﻿using System.Collections.Immutable;
using System.Linq;
using Solution.Parser.CSharp;

namespace RunJIT.CodeRules.Api.Controllers
{
    [TestClass]
    public class ControllerTestBase : MsTestBase
    {
        public IImmutableList<Class> Controllers { get; set; } = ImmutableList<Class>.Empty;
        public ImmutableList<Class> RestControllers { get; set; } = ImmutableList<Class>.Empty;
        public ImmutableList<Class> ActionControllers { get; set; } = ImmutableList<Class>.Empty;

        public ControllerTestBase()
        {
            Controllers = (from syntaxTree in ProductiveSyntaxTrees
                           from @class in syntaxTree.Classes
                           where @class.BaseTypes.Any(baseType => baseType.TypeName == "ControllerBase")
                           select @class).ToImmutableList();


            ActionControllers = Controllers.Where(controller => controller.Methods.All(m => m.Attributes.Any(a => a.Name.Contains("HttpPost")))).ToImmutableList();
            RestControllers = Controllers.Except(ActionControllers).ToImmutableList();
        }
    }
}
