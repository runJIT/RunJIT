﻿using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Extensions.Pack;
using RunJIT.CodeRules.Mediator;
using Solution.Parser.CSharp;

namespace RunJIT.CodeRules.Services
{
    [TestClass]
    public class ServiceTestBase : MsTestBase
    {
        protected ImmutableList<(Class Class, Class? Registration, CSharpSyntaxTree syntaxTree)> Services { get; set; } = ImmutableList<(Class Class, Class? Registration, CSharpSyntaxTree syntaxTree)>.Empty;

        public ServiceTestBase()
        {
            Services = FindServices().ToImmutableList();

            IEnumerable<(Class Class, Class? Registration, CSharpSyntaxTree syntaxTree)> FindServices()
            {
                foreach (var cSharpSyntaxTree in ProductiveSyntaxTrees)
                {
                    var services = cSharpSyntaxTree.Classes.Where(@class => @class.Modifiers.Any(m => m is Modifier.Static or Modifier.Abstract).IsFalse() &&
                                                                            MediatorTestBase.HandlerInterfaces.Any(type => @class.BaseTypes.Any(t => t.TypeName.StartWith(type))).IsFalse() &&
                                                                            @class.Methods.Any() &&
                                                                            (@class.BaseTypes.IsEmpty() || @class.BaseTypes.Any(t => t.TypeName.StartWith("I")))).ToImmutableList();

                    foreach (var service in services)
                    {
                        var registrationClass = cSharpSyntaxTree.Classes.FirstOrDefault(@class => @class.Name.Contains(service.Name) && @class.Name.Contains("Extension"));
                        yield return (service, registrationClass, cSharpSyntaxTree);
                    }
                }
            }
        }
    }
}
