﻿using System.Net.Http;
using System.Threading.Tasks;
using AspNetCore.Simple.Sdk.Serializer.Json;
using Extensions.Pack;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Pulse.Common.Api;
namespace rps.template
{
    public static class AddJsonResponseTypeHandlerExtension
    {
        public static void AddJsonResponseTypeHandler(this IServiceCollection services)
        {
            services.AddSingletonIfNotExists<ISpecificResponseTypeHandler, JsonResponseTypeHandler>();
        }
    }

    internal class JsonResponseTypeHandler : ISpecificResponseTypeHandler
    {
        private readonly IJsonSerializer _jsonSerializer;

        public JsonResponseTypeHandler(IJsonSerializer jsonSerializer)
        {
            _jsonSerializer = jsonSerializer;
        }

        public bool CanHandle<TResult>(HttpResponseMessage responseMessage)
        {
            return responseMessage.IsSuccessStatusCode &&
                   typeof(TResult) != typeof(byte[]) &&
                   typeof(TResult) != typeof(FileStreamResult);
        }

        public async Task<TResult> HandleAsync<TResult>(HttpResponseMessage responseMessage, HttpMethod httpMethod, HttpClient httpClient, string url)
        {
            // Safety first this method can be called without CanHandle check !
            CanHandle<TResult>(responseMessage);

            var content = await responseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = _jsonSerializer.Deserialize<TResult>(content);
            return result;
        }
    }
}
