﻿using System;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Siemens.AspNet.ErrorHandling.Contracts;

namespace rps.template
{
    internal static class AddHttpCallHandlerExtension
    {
        internal static void AddHttpCallHandler(this IServiceCollection services)
        {
            services.AddResponseTypeHandleStrategy();
            services.AddHttpRequestMessageBuilder();
            services.AddHttpCallHandlerFactory();

            services.AddHttpClient();
        }
    }

    public interface IHttpCallHandler
    {
        Task CallAsync(HttpMethod httpMethod,
                       string url,
                       object? payload,
                       CancellationToken cancellationToken,
                       [CallerArgumentExpression(nameof(payload))]
                       string payloadParameterName = "");

        Task<TResult> CallAsync<TResult>(HttpMethod httpMethod,
                                         string url,
                                         object? payload,
                                         CancellationToken cancellationToken,
                                         [CallerArgumentExpression(nameof(payload))]
                                         string payloadParameterName = "");
    }

    internal sealed class HttpCallHandler(HttpClient httpClient,
                                          ResponseTypeHandleStrategy responseHandleStrategy,
                                          HttpRequestMessageBuilder httpRequestMessageBuilder) : IHttpCallHandler
    {
        public async Task CallAsync(HttpMethod httpMethod,
                                    string url,
                                    object? payload,
                                    CancellationToken cancellationToken,
                                    [CallerArgumentExpression(nameof(payload))]
                                    string payloadParameterName = "")
        {
            var message = httpRequestMessageBuilder.BuildFrom(httpMethod, url, payload,
                                                              payloadParameterName);

            var response = await httpClient.SendAsync(message, cancellationToken).ConfigureAwait(false);

            if (response.IsSuccessStatusCode)
            {
                return;
            }

            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            var absoluteUrl = $"{httpClient.BaseAddress}{url}";

            throw new ProblemDetailsException(response.StatusCode,
                                              "Client call to endpoint was not successful",
                                              $"The http call: {httpMethod.Method} {url} was not successful",
                                              ("HttpMethod", httpMethod.Method),
                                              ("Url", absoluteUrl),
                                              ("Error", content));
        }

        public async Task<TResult> CallAsync<TResult>(HttpMethod httpMethod,
                                                      string url,
                                                      object? payload,
                                                      CancellationToken cancellationToken,
                                                      [CallerArgumentExpression(nameof(payload))]
                                                      string payloadParameterName = "")
        {
            var message = httpRequestMessageBuilder.BuildFrom(httpMethod, url, payload,
                                                              payloadParameterName);

            var response = await httpClient.SendAsync(message, cancellationToken).ConfigureAwait(false);

            var result = await responseHandleStrategy.HandleAsync<TResult>(response, httpMethod, httpClient,
                                                                           url).ConfigureAwait(false);

            return result;
        }

        public async Task CallAsync(Func<HttpClient, string, string, Task<HttpResponseMessage>> httpFunction,
                                    HttpMethod httpMethod,
                                    string url,
                                    string payload)
        {
            var response = await httpFunction(httpClient, url, payload);

            if (response.IsSuccessStatusCode)
            {
                return;
            }

            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var absoluteUrl = $"{httpClient.BaseAddress}{url}";

            throw new ProblemDetailsException(response.StatusCode,
                                              "Client call to endpoint was not successfull",
                                              $"The http call: {httpMethod.Method} {url} was not successful",
                                              ("HttpMethod", httpMethod.Method),
                                              ("Url", absoluteUrl),
                                              ("Error", content));
        }

        public async Task<TResult> CallAsync<TResult>(Func<HttpClient, string, string, Task<HttpResponseMessage>> httpFunction,
                                                      HttpMethod httpMethod,
                                                      string url,
                                                      string payload)
        {
            var response = await httpFunction(httpClient, url, payload);

            var result = await responseHandleStrategy.HandleAsync<TResult>(response, httpMethod, httpClient,
                                                                           url).ConfigureAwait(false);

            return result;
        }
    }
}