﻿using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Siemens.AspNet.ErrorHandling.Contracts;

namespace rps.template
{
    internal static class AddJsonResponseTypeHandlerExtension
    {
        internal static void AddJsonResponseTypeHandler(this IServiceCollection services)
        {
            services.AddJsonSerializer();

            services.AddSingletonIfNotExists<ISpecificResponseTypeHandler, JsonResponseTypeHandler>();
        }
    }

    internal sealed class JsonResponseTypeHandler(IJsonSerializer jsonSerializer) : ISpecificResponseTypeHandler
    {
        public bool CanHandle<TResult>(HttpResponseMessage responseMessage)
        {
            return responseMessage.IsSuccessStatusCode &&
                   typeof(TResult) != typeof(byte[]) &&
                   typeof(TResult) != typeof(FileStreamResult);
        }

        public async Task<TResult> HandleAsync<TResult>(HttpResponseMessage responseMessage,
                                                        HttpMethod httpMethod,
                                                        HttpClient httpClient,
                                                        string url)
        {
            // Safety first this method can be called without CanHandle check !
            if (CanHandle<TResult>(responseMessage).IsFalse())
            {
                throw new InternalServerErrorDetailsException("JsonResponseTypeHandler was called without checking CanHandle.",
                                                              $"The response type handler for type: {typeof(TResult).Name} is not supported",
                                                              ("SupportedTypes", "Serializable content"));
            }

            var content = await responseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = jsonSerializer.Deserialize<TResult>(content);

            return result;
        }
    }
}