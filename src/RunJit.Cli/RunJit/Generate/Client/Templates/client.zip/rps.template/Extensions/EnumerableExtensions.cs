﻿using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace rps.template
{
    internal static class EnumerableExtensions
    {
        internal static string ToQueryParams<T>(this IEnumerable<T>? parameters, string parameterName)
        {
            if (parameters.IsNull())
            {
                return string.Empty;
            }

            var result = parameters.Select(param =>
            {
                if (param is string stringParameter)
                {
                    return $"{parameterName}={HttpUtility.UrlEncode(stringParameter)}";
                }

                return $"{parameterName}={param}";
            });
            var flattenParams = result.Flatten("&");
            return flattenParams;
        }
        
        /// <summary>Flattens the specified strings.</summary>
        /// <param name="strings">The strings.</param>
        /// <param name="separator">A separator, which will be used in between the single values.</param>
        /// <returns>The strings flattened to a single string.</returns>
        internal static string Flatten(this IEnumerable<string> strings)
        {
            return strings.Flatten(string.Empty);
        }
        
        /// <summary>Flattens the specified strings.</summary>
        /// <param name="strings">The strings.</param>
        /// <param name="separator">A separator, which will be used in between the single values.</param>
        /// <returns>The strings flattened to a single string.</returns>
        internal static string Flatten(this IEnumerable<string> strings, string separator)
        {
            return string.Join(separator, strings);
        }
    }
}
