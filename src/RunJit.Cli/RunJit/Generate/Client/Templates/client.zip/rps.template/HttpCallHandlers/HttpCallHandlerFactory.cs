﻿using System.Net.Http;
using Microsoft.Extensions.DependencyInjection;

namespace rps.template
{
    internal static class AddHttpCallHandlerFactoryExtension
    {
        internal static void AddHttpCallHandlerFactory(this IServiceCollection services)
        {
            services.AddResponseTypeHandleStrategy();
            services.AddHttpRequestMessageBuilder();

            services.AddSingletonIfNotExists<HttpCallHandlerFactory>();
        }
    }

    internal sealed class HttpCallHandlerFactory(ResponseTypeHandleStrategy responseTypeHandleStrategy,
                                                 HttpRequestMessageBuilder httpRequestMessageBuilder)
    {
        internal HttpCallHandler CreateFrom(HttpClient client)
        {
            return new HttpCallHandler(client, responseTypeHandleStrategy, httpRequestMessageBuilder);
        }
    }
}