﻿using System;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Pulse.Contracts.Exceptions;

namespace rps.template
{
    public class MissingSettingsException<TSettings> : Exception where TSettings : class
    {
        internal MissingSettingsException() : base($"The setting: '{typeof(TSettings).Name}' is missing. Please check your specific appsettings.json or your environment variables.")
        {
        }
    }

    internal static class ServiceCollectionExtensions
    {
        internal static bool IsAlreadyRegistered<TImplementation>(this IServiceCollection services)
            where TImplementation : class
        {
            var existingRegistrations = services.Where(descriptor => descriptor.IsKeyedService.IsFalse() &&
                                                                     (descriptor.ServiceType == typeof(TImplementation) ||
                                                                      descriptor.ImplementationType == typeof(TImplementation)));

            return existingRegistrations.Any();
        }

        internal static T GetOrThrowMissingException<T>(this IServiceProvider services)
        {
            var service = services.GetService<T>();

            if (service.IsNull())
            {
                throw new ProblemDetailsException("Service could not be resolved",
                                                  $"The service: {typeof(T).Name} could not be resolved please check your service registrations",
                                                  ("One time registration", $"services.{nameof(AddSingletonIfNotExists)}<{typeof(T).Name}>();"),
                                                  ("Standard registration", $"services.AddSingleton<{typeof(T).Name}>();"));
            }

            return service;
        }

        internal static void AddSingletonOption<T>(this IServiceCollection serviceCollection, IConfiguration configuration) where T : class, new()
        {
            var setting = configuration.GetSettings<T>();

            if (setting.IsNull())
            {
                throw new ProblemDetailsException(500,
                                                  $"Setting of type: {typeof(T).Name} could not be found",
                                                  $"Please check your appsettings.json, or check if the name of your class '{typeof(T).Name}' mach the section name in your appsettings.json");
            }

            serviceCollection.AddSingletonIfNotExists(setting);
        }

        internal static void AddSingletonIfNotExists<TImplementation>(this IServiceCollection services)
            where TImplementation : class
        {
            services.AddSingletonIfNotExists<TImplementation, TImplementation>();
        }

        internal static void AddSingletonIfNotExists<TImplementation>(this IServiceCollection services, TImplementation instance)
            where TImplementation : class
        {
            var existingRegistrations = services.Where(descriptor => descriptor.ServiceType == typeof(TImplementation));

            if (existingRegistrations.Any())
            {
                return;
            }

            services.AddSingleton(instance);
        }

        internal static void AddSingletonIfNotExists<TInterface, TImplementation>(this IServiceCollection services)
            where TInterface : class
            where TImplementation : class, TInterface
        {
            var existingRegistrations = services.Where(descriptor => descriptor.ServiceType == typeof(TInterface) && descriptor.ImplementationType == typeof(TImplementation));

            if (existingRegistrations.Any())
            {
                return;
            }

            services.AddSingleton(typeof(TInterface), typeof(TImplementation));
        }

        internal static T GetSettings<T>(this IConfiguration configuration) where T : class, new()
        {
            var originalTypeSettings = configuration.TryGetSettings<T>(out var settings);

            if (originalTypeSettings)
            {
                return settings;
            }

            var typeNameTrimmedSettings = typeof(T).Name;

            return configuration.GetSettings<T>(typeNameTrimmedSettings);
        }

        public static T GetSettings<T>(this IConfiguration configuration, string settingsKeyPath)
            where T : class
        {
            var settings = configuration.GetSection(settingsKeyPath).Get<T>();

            if (settings.IsNull())
            {
                throw new MissingSettingsException<T>();
            }

            return settings;
        }

        internal static bool TryGetSettings<T>(this IConfiguration configuration, out T settings) where T : new()
        {
            // original settings by type name
            var type = typeof(T);
            var settingsByTypeExists = configuration.TryGetSettings(type.Name, out settings);

            if (settingsByTypeExists is false)
            {
                return configuration.TryGetSettings(type.Name, out settings);
            }

            return settingsByTypeExists;
        }

        internal static bool TryGetSettings<T>(this IConfiguration configuration, string settingsKeyPath, out T settings) where T : new()
        {
            var section = configuration.GetSection(settingsKeyPath).Get<T>();

            if (section is null)
            {
                settings = new T();

                return false;
            }

            settings = section;

            return true;
        }

        internal static T GetSettingsAndRegisterAsSingleton<T>(this IServiceCollection serviceCollection,
            IConfiguration configuration,
            string? settingsKeyPath = null) where T : class, new()
        {
            var setting = settingsKeyPath is null ? configuration.GetSettings<T>() : configuration.GetSettings<T>(settingsKeyPath);

            serviceCollection.AddSingletonIfNotExists(setting);

            return setting;
        }
    }
}