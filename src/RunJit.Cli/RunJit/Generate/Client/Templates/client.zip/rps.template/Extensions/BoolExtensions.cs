﻿namespace rps.template
{
    /// <summary>Provides extension methods for the <see cref="bool" /> type.</summary>
    internal static class BoolExtensions
    {
        /// <summary>Negates the specified source.</summary>
        /// <param name="source">If set to <c>true</c> <c>false</c> will be returned and otherwise.</param>
        /// <returns>The negated source of the given bool.</returns>
        internal static bool IsFalse(this bool source)
        {
            return !source;
        }
    }
}
