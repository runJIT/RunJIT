﻿namespace rps.template
{
    internal static class BoolExtensions
    {
        internal static bool IsFalse(this bool source)
        {
            return !source;
        }
    }
}