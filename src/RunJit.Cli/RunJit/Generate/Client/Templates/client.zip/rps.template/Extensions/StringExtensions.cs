﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;

namespace rps.template
{
    /// <summary>Represents the extensions for the <see cref="string" /> class.</summary>
    internal static class StringExtensions
    {
        /// <summary>Checks if the source string is null or empty.</summary>
        /// <param name="source">The source.</param>
        /// <returns><c>True</c> if source string is null or empty; otherwise <c>False</c>.</returns>
        internal static bool IsNullOrEmpty([NotNullWhen(false)] this string? source)
        {
            return string.IsNullOrEmpty(source);
        }

        /// <summary>Checks if the source string is NOT null or empty.</summary>
        /// <param name="source">The source.</param>
        /// <returns><c>True</c> if source string is null or empty; otherwise <c>False</c>.</returns>
        internal static bool IsNotNullOrEmpty([NotNullWhen(true)] this string? source)
        {
            return !source.IsNullOrEmpty();
        }

        /// <summary>Checks if the source string is empty.</summary>
        /// <param name="source">The source string.</param>
        /// <returns><c>True</c> if source string is empty; otherwise <c>False</c>.</returns>
        internal static bool IsEmpty(this string source)
        {
            return source == string.Empty;
        }

        /// <summary>Checks if the source string is not empty.</summary>
        /// <param name="source">The source string.</param>
        /// <returns><c>True</c> if source string is not empty; otherwise <c>False</c>.</returns>
        internal static bool IsNotEmpty(this string source)
        {
            return !source.IsEmpty();
        }

        /// <summary>Comfort way to use starts with, using <see cref="StringComparison.OrdinalIgnoreCase" /> as the string comparison.</summary>
        /// <param name="source">The source.</param>
        /// <param name="value">The value.</param>
        /// <returns><c>True</c> if source string starts with expected value; otherwise <c>False</c>.</returns>
        internal static bool StartWith(this string source, string value)
        {
            return source.StartsWith(value, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>Comfort way to use ends with, using <see cref="StringComparison.OrdinalIgnoreCase" /> as the string comparison.</summary>
        /// <param name="source">The source.</param>
        /// <param name="value">The value.</param>
        /// <returns><c>True</c> if source string starts with expected value; otherwise <c>False</c>.</returns>
        internal static bool EndWith(this string source, string value)
        {
            var result = source.EndsWith(value, StringComparison.OrdinalIgnoreCase);

            return result;
        }

        /// <summary>Checks if the source string is null or whitespace.</summary>
        /// <param name="source">The source.</param>
        /// <returns><c>True</c> if source string is null or only a whitespace; otherwise <c>False</c>.</returns>
        internal static bool IsNullOrWhiteSpace([NotNullWhen(false)] this string? source)
        {
            return string.IsNullOrWhiteSpace(source);
        }

        internal static string FirstCharToUpper(this string input)
        {
            if (input.IsNullOrWhiteSpace())
            {
                return input;
            }

            return $"{input.First().ToString(CultureInfo.InvariantCulture).ToUpper(CultureInfo.InvariantCulture)}{input[1..]}";
        }

        public static string FirstCharToLower(this string input)
        {
            if (input.IsNullOrWhiteSpace())
            {
                return input;
            }

            return input.First().ToString(CultureInfo.InvariantCulture).ToLower(CultureInfo.InvariantCulture) + input[1..];
        }
    }
}
