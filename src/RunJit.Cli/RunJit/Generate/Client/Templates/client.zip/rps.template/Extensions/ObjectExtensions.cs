﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace rps.template
{
    internal static class ObjectExtensions
    {
        /// <summary>Determines whether the specified source is not null.</summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if the source is not null; otherwise, <c>false</c>.</returns>
        internal static bool IsNotNull([NotNullWhen(true)] this object? source)
        {
            return source is not null;
        }

        /// <summary>Determines whether the specified source is null.</summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if the source is null; otherwise, <c>false</c>.</returns>
        internal static bool IsNull([NotNullWhen(false)] this object? source)
        {
            // No argument checking here, because the extension checks for null.
            return source is null;
        }

        /// <summary>Cast an object to a specific type unsafe.</summary>
        /// <param name="source">The source object which have to be casted.</param>
        /// <typeparam name="T">The generic type which will be expected.</typeparam>
        /// <returns><c>T</c> of the safe casted object; otherwise <c>null</c>.</returns>
        public static T Cast<T>(this object source)
        {
            return (T)source;
        }
    }

    internal static class GenericTypeExtensions
    {
        /// <summary>Converts an enum to an int.</summary>
        /// <typeparam name="T">The generic type parameter.</typeparam>
        /// <param name="value">The enum value.</param>
        /// <returns>The converted int.</returns>
        internal static int ToInt<T>(this T value)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            return value.ToIntOrDefault(default);
        }

        /// <summary>Converts an enum to an int.</summary>
        /// <typeparam name="T">The generic type parameter.</typeparam>
        /// <param name="value">The enum value.</param>
        /// <returns>The converted int.</returns>
        internal static int ToInt<T>(this T? value)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            return value.ToIntOrDefault(default);
        }

        /// <summary>Converts an enum to an int or to a default value if it is null.</summary>
        /// <typeparam name="T">The generic type parameter.</typeparam>
        /// <param name="value">The enum value.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns>The converted int.</returns>
        internal static int ToIntOrDefault<T>(this T? value, int defaultValue)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            if (value == null)
            {
                return defaultValue;
            }

            return value.Cast<int>();
        }

        internal static int ToIntOrDefault<T>(this T value, int defaultValue)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            return value.Cast<int>();
        }
    }
}